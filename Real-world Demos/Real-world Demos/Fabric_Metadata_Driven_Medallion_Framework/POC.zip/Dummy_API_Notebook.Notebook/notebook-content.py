# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "8e3a0528-c97f-4ffe-a9eb-122c0986f836",
# META       "default_lakehouse_name": "RetailLakehouse",
# META       "default_lakehouse_workspace_id": "af8d3bd6-7c44-4d7f-961b-1e9fc550ac86",
# META       "known_lakehouses": [
# META         {
# META           "id": "8e3a0528-c97f-4ffe-a9eb-122c0986f836"
# META         }
# META       ]
# META     },
# META     "warehouse": {
# META       "default_warehouse": "9bdd0537-def6-4b2b-bc81-519b6bec357a",
# META       "known_warehouses": [
# META         {
# META           "id": "9bdd0537-def6-4b2b-bc81-519b6bec357a",
# META           "type": "Lakewarehouse"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

import requests
import json
from datetime import datetime

# Use notebookutils.fs to ensure directory exists and to write into default Lakehouse Files
# In Fabric Spark notebooks, relative paths like "Files/..." point to the default Lakehouse.

api_url = "https://dummyjson.com/products"

response = requests.get(api_url)
response.raise_for_status()

data = response.json()

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

# Target folder under the default Lakehouse Files
target_folder = "Files/API"

# Ensure the API folder exists in the Lakehouse Files area
if not notebookutils.fs.exists(target_folder):
    notebookutils.fs.mkdirs(target_folder)

# Build the full path using the Lakehouse-relative convention
output_path = f"{target_folder}/products_{timestamp}.json"

# Write JSON content using notebookutils.fs.put (avoids local FS issues)
notebookutils.fs.put(output_path, json.dumps(data, indent=4), overwrite=True)

print(f"API data successfully saved to Lakehouse path: {output_path}")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
