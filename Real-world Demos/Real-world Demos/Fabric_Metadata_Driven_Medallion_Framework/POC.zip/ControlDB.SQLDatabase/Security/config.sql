CREATE SCHEMA [config]
    AUTHORIZATION [abuddhabhatti@MVPsOnFabric.onmicrosoft.com];


GO

