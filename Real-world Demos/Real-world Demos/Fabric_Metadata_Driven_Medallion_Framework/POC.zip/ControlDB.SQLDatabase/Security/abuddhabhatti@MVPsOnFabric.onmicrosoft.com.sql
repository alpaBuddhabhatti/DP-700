CREATE USER [abuddhabhatti@MVPsOnFabric.onmicrosoft.com]
    WITH SID = 0xE7E55C766F5BB341B8D959CB96C381C4, TYPE = E;


GO

