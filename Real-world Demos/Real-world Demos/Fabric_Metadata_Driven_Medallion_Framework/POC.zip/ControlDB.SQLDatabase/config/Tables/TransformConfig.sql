CREATE TABLE [config].[TransformConfig] (
    [Transform_Id]             INT            IDENTITY (1, 1) NOT NULL,
    [Spec_Code]                VARCHAR (100)  NOT NULL,
    [Transform_Layer]          VARCHAR (50)   NOT NULL,
    [Transform_Code]           VARCHAR (100)  NOT NULL,
    [Transform_Name]           VARCHAR (200)  NULL,
    [Source_Tables_JSON]       VARCHAR (MAX)  NULL,
    [Target_Table]             VARCHAR (300)  NOT NULL,
    [Transform_Type]           VARCHAR (50)   NOT NULL,
    [Transform_SQL]            VARCHAR (MAX)  NOT NULL,
    [Merge_Key_Columns]        VARCHAR (1000) NULL,
    [Delete_Detection_Enabled] BIT            DEFAULT ((0)) NOT NULL,
    [Delete_Column]            VARCHAR (200)  NULL,
    [Delete_Value]             VARCHAR (100)  NULL,
    [Execution_Order]          INT            NOT NULL,
    [Is_Active]                BIT            DEFAULT ((1)) NOT NULL,
    [Created_At]               DATETIME2 (7)  DEFAULT (sysutcdatetime()) NULL,
    [Updated_At]               DATETIME2 (7)  NULL,
    PRIMARY KEY CLUSTERED ([Transform_Id] ASC)
);


GO

