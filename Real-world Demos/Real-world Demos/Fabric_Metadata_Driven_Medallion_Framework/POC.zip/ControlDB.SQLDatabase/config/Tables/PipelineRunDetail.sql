CREATE TABLE [config].[PipelineRunDetail] (
    [Pipeline_Run_Detail_Id] VARCHAR (100) NOT NULL,
    [Pipeline_Run_Id]        VARCHAR (100) NOT NULL,
    [Spec_Code]              VARCHAR (100) NOT NULL,
    [Dataset_Code]           VARCHAR (100) NOT NULL,
    [Source_Type]            VARCHAR (50)  NULL,
    [Source_Name]            VARCHAR (300) NULL,
    [Target_Name]            VARCHAR (300) NULL,
    [Start_Time]             DATETIME2 (7) NOT NULL,
    [End_Time]               DATETIME2 (7) NULL,
    [Status]                 VARCHAR (50)  NOT NULL,
    [Rows_Read]              BIGINT        NULL,
    [Rows_Written]           BIGINT        NULL,
    [Error_Message]          VARCHAR (MAX) NULL,
    [Created_At]             DATETIME2 (7) DEFAULT (sysutcdatetime()) NULL,
    PRIMARY KEY CLUSTERED ([Pipeline_Run_Detail_Id] ASC)
);


GO

