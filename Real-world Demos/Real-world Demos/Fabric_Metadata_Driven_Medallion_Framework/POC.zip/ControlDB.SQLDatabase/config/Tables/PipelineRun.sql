CREATE TABLE [config].[PipelineRun] (
    [Pipeline_Run_Id] VARCHAR (100) NOT NULL,
    [Spec_Code]       VARCHAR (100) NOT NULL,
    [Pipeline_Name]   VARCHAR (200) NULL,
    [Start_Time]      DATETIME2 (7) NOT NULL,
    [End_Time]        DATETIME2 (7) NULL,
    [Status]          VARCHAR (50)  NOT NULL,
    [Triggered_By]    VARCHAR (200) NULL,
    [Error_Message]   VARCHAR (MAX) NULL,
    [Created_At]      DATETIME2 (7) DEFAULT (sysutcdatetime()) NULL,
    PRIMARY KEY CLUSTERED ([Pipeline_Run_Id] ASC)
);


GO

