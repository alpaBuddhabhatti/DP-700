CREATE TABLE [config].[EmailNotificationConfig] (
    [Email_Config_Id]          INT           IDENTITY (1, 1) NOT NULL,
    [Spec_Code]                VARCHAR (100) NOT NULL,
    [Email_To]                 VARCHAR (MAX) NOT NULL,
    [Email_From]               VARCHAR (300) NULL,
    [Email_CC]                 VARCHAR (MAX) NULL,
    [Email_BCC]                VARCHAR (MAX) NULL,
    [Email_Subject]            VARCHAR (500) NOT NULL,
    [Email_Message]            VARCHAR (MAX) NULL,
    [Is_Attachment_Required]   BIT           DEFAULT ((0)) NOT NULL,
    [Attachment_Path]          VARCHAR (MAX) NULL,
    [Send_On_Success]          BIT           DEFAULT ((1)) NOT NULL,
    [Send_On_Failure]          BIT           DEFAULT ((1)) NOT NULL,
    [Is_Active]                BIT           DEFAULT ((1)) NOT NULL,
    [Last_Email_Status]        VARCHAR (50)  NULL,
    [Last_Email_Error_Message] VARCHAR (MAX) NULL,
    [Last_Email_Sent_At]       DATETIME2 (7) NULL,
    [Created_At]               DATETIME2 (7) DEFAULT (sysutcdatetime()) NULL,
    [Updated_At]               DATETIME2 (7) NULL,
    PRIMARY KEY CLUSTERED ([Email_Config_Id] ASC)
);


GO

