CREATE TABLE [config].[WatermarkControl] (
    [Watermark_Id]         INT           IDENTITY (1, 1) NOT NULL,
    [Spec_Code]            VARCHAR (100) NOT NULL,
    [Dataset_Code]         VARCHAR (100) NOT NULL,
    [Watermark_Column]     VARCHAR (200) NOT NULL,
    [Window_Start_Value]   VARCHAR (200) NULL,
    [Window_End_Value]     VARCHAR (200) NULL,
    [Next_Watermark_Value] VARCHAR (200) NULL,
    [Lookback_Days]        INT           NULL,
    [Last_Run_Id]          VARCHAR (100) NULL,
    [Updated_At]           DATETIME2 (6) NULL
);


GO

