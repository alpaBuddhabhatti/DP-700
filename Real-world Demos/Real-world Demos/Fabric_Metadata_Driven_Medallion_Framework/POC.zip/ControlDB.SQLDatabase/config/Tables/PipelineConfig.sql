CREATE TABLE [config].[PipelineConfig] (
    [Config_Id]                  INT            IDENTITY (1, 1) NOT NULL,
    [Spec_Code]                  VARCHAR (100)  NOT NULL,
    [Dataset_Code]               VARCHAR (100)  NOT NULL,
    [Dataset_Name]               VARCHAR (200)  NULL,
    [Source_Type]                VARCHAR (50)   NOT NULL,
    [Source_SubType]             VARCHAR (50)   NULL,
    [Source_Connection_Name]     VARCHAR (200)  NULL,
    [Source_Object_Name]         VARCHAR (300)  NULL,
    [Source_Path]                VARCHAR (1000) NULL,
    [Target_Layer]               VARCHAR (50)   NOT NULL,
    [Target_Type]                VARCHAR (50)   NOT NULL,
    [Target_Name]                VARCHAR (300)  NOT NULL,
    [Load_Pattern]               VARCHAR (50)   NOT NULL,
    [Where_Condition]            VARCHAR (MAX)  NULL,
    [Watermark_Enabled]          BIT            DEFAULT ((0)) NOT NULL,
    [Watermark_Column]           VARCHAR (200)  NULL,
    [Delete_Detection_Enabled]   BIT            DEFAULT ((0)) NOT NULL,
    [Delete_Column]              VARCHAR (200)  NULL,
    [Delete_Value]               VARCHAR (100)  NULL,
    [Merge_Key_Columns]          VARCHAR (1000) NULL,
    [Config_JSON]                VARCHAR (MAX)  NULL,
    [Email_Notification_Enabled] BIT            DEFAULT ((0)) NOT NULL,
    [Execution_Order]            INT            NOT NULL,
    [Is_Active]                  BIT            DEFAULT ((1)) NOT NULL,
    [Created_At]                 DATETIME2 (7)  DEFAULT (sysutcdatetime()) NULL,
    [Updated_At]                 DATETIME2 (7)  NULL,
    [Source_File_Name]           VARCHAR (255)  NULL,
    [Sheet_Name]                 VARCHAR (50)   NULL,
    [Row_Range]                  VARCHAR (50)   NULL,
    [Additional_Configurations]  JSON           NULL,
    PRIMARY KEY CLUSTERED ([Config_Id] ASC)
);


GO

