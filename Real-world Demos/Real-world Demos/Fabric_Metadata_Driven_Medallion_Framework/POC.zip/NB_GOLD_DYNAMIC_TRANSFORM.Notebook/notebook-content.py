# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "8e3a0528-c97f-4ffe-a9eb-122c0986f836",
# META       "default_lakehouse_name": "RetailLakehouse",
# META       "default_lakehouse_workspace_id": "af8d3bd6-7c44-4d7f-961b-1e9fc550ac86",
# META       "known_lakehouses": [
# META         {
# META           "id": "8e3a0528-c97f-4ffe-a9eb-122c0986f836"
# META         }
# META       ]
# META     },
# META     "warehouse": {
# META       "default_warehouse": "9bdd0537-def6-4b2b-bc81-519b6bec357a",
# META       "known_warehouses": [
# META         {
# META           "id": "9bdd0537-def6-4b2b-bc81-519b6bec357a",
# META           "type": "Lakewarehouse"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

# ============================================
# NB_GOLD_DYNAMIC_TRANSFORM
# Reads Gold transform config from ControlDB.config.TransformConfig
# Runs only if matching Gold config exists.
# ============================================

import com.microsoft.sqlserver.jdbc.spark
from pyspark.sql.functions import col

Spec_Code = globals().get("Spec_Code", "BO5")
Dataset_Code = globals().get("Dataset_Code", "API_PRODUCTS")
Transform_Layer = globals().get("Transform_Layer", "Gold")

control_db_server = "r6jir4thcxbujmagvc37ynczku-2y5y3l2epr7u3fq3d2p4kufmqy.msit-database.fabric.microsoft.com"
control_db_name = "ControlDB-32cb020c-4245-4f3e-94c5-40c1204b8058"

url = (
    f"jdbc:sqlserver://{control_db_server}:1433;"
    f"database={control_db_name};"
    f"encrypt=true;"
    f"trustServerCertificate=false;"
)

config_df = (
    spark.read
    .option("url", url)
    .mssql("config.TransformConfig")
)

config_df = config_df.filter(
    (col("Spec_Code") == Spec_Code) &
    (col("Transform_Layer") == Transform_Layer) &
    (col("Transform_Code") == Dataset_Code) &
    (col("Is_Active") == 1)
)

rows = config_df.collect()

if len(rows) == 0:
    print(
        f"No active Gold transform found for "
        f"Spec_Code={Spec_Code}, Dataset_Code={Dataset_Code}. Skipping."
    )
else:
    config_row = rows[0].asDict()

    Transform_Code = config_row["Transform_Code"]
    Target_Table = config_row["Target_Table"]
    Transform_SQL = config_row["Transform_SQL"]
    Write_Mode = config_row.get("Write_Mode") or "overwrite"

    print("============================================")
    print("NB_GOLD_DYNAMIC_TRANSFORM started")
    print(f"Spec_Code       : {Spec_Code}")
    print(f"Dataset_Code    : {Dataset_Code}")
    print(f"Transform_Layer : {Transform_Layer}")
    print(f"Transform_Code  : {Transform_Code}")
    print(f"Target_Table    : {Target_Table}")
    print("============================================")

    df = spark.sql(Transform_SQL)

    df.write \
        .format("delta") \
        .mode(Write_Mode) \
        .option("overwriteSchema", "true") \
        .saveAsTable(Target_Table)

    print(f"Gold transform completed: {Target_Table}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
