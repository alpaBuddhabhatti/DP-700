# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "8e3a0528-c97f-4ffe-a9eb-122c0986f836",
# META       "default_lakehouse_name": "RetailLakehouse",
# META       "default_lakehouse_workspace_id": "af8d3bd6-7c44-4d7f-961b-1e9fc550ac86",
# META       "known_lakehouses": [
# META         {
# META           "id": "8e3a0528-c97f-4ffe-a9eb-122c0986f836"
# META         }
# META       ]
# META     },
# META     "warehouse": {
# META       "default_warehouse": "e6e9d431-349d-4e08-89b5-3270e99295f7",
# META       "known_warehouses": [
# META         {
# META           "id": "e6e9d431-349d-4e08-89b5-3270e99295f7",
# META           "type": "MountedWarehouse"
# META         }
# META       ]
# META     },
# META     "mirrored_db": {
# META       "known_mirrored_dbs": []
# META     }
# META   }
# META }

# CELL ********************

# ============================================
# NB_BRONZE_API_INGESTION
# Reads API ingestion settings from ControlDB.config.PipelineConfig
# using Fabric Spark connector for SQL databases.
#
# Notebook parameters:
#   Pipeline_Run_Id
#   Spec_Code
#   Dataset_Code
# ============================================

import json
import requests
import com.microsoft.sqlserver.jdbc.spark
from pyspark.sql.functions import current_timestamp, lit, col

# -----------------------------
# Manual defaults for testing
# -----------------------------
Pipeline_Run_Id = globals().get("Pipeline_Run_Id", "TEST-RUN-0011")
Spec_Code = globals().get("Spec_Code", "BO5")
Dataset_Code = globals().get("Dataset_Code", "API_CATEGORIES")

# -----------------------------
# ControlDB connection
# Replace SERVER_NAME with ControlDB SQL connection server name
# Example format:
# xxxxx.database.fabric.microsoft.com
# -----------------------------


control_db_server = "r6jir4thcxbujmagvc37ynczku-2y5y3l2epr7u3fq3d2p4kufmqy.msit-database.fabric.microsoft.com"
control_db_name = "ControlDB-32cb020c-4245-4f3e-94c5-40c1204b8058"

url = (
    f"jdbc:sqlserver://{control_db_server}:1433;"
    f"database={control_db_name};"
    f"encrypt=true;"
    f"trustServerCertificate=false;"
)

# -----------------------------
# Read PipelineConfig from ControlDB
# -----------------------------
config_df = (
    spark.read
    .option("url", url)
    .mssql("config.PipelineConfig")
)

config_df = config_df.filter(
    (col("Spec_Code") == Spec_Code) &
    (col("Dataset_Code") == Dataset_Code) &
    (col("Source_Type") == "API") &
    (col("Is_Active") == 1)
)

config_rows = config_df.collect()

if len(config_rows) == 0:
    raise ValueError(
        f"No active API config found for Spec_Code={Spec_Code}, Dataset_Code={Dataset_Code}"
    )

if len(config_rows) > 1:
    raise ValueError(
        f"Multiple active API config rows found for Spec_Code={Spec_Code}, Dataset_Code={Dataset_Code}"
    )

config_row = config_rows[0].asDict()

Data_Source = config_row.get("Source_Path")
Target_Name = config_row.get("Target_Name")
Metadata_Config = config_row.get("Config_JSON") or "{}"

if not Data_Source:
    raise ValueError("Source_Path is required in config.PipelineConfig.")

if not Target_Name:
    raise ValueError("Target_Name is required in config.PipelineConfig.")

metadata_config = json.loads(Metadata_Config)

method = metadata_config.get("method", "GET")
auth_type = metadata_config.get("authType", "None")
data_path = metadata_config.get("dataPath", "value")
pagination_type = metadata_config.get("paginationType", "odataNextLink")
next_link_path = metadata_config.get("nextLinkPath", "@odata.nextLink")
write_mode = metadata_config.get("writeMode", "overwrite")
timeout_seconds = int(metadata_config.get("timeoutSeconds", 60))

headers = {}

if auth_type.lower() != "none":
    raise NotImplementedError("Only authType=None is implemented for this demo.")

def get_path_value(payload, path):
    if not path:
        return payload

    current = payload
    for part in path.split("."):
        if isinstance(current, dict):
            current = current.get(part)
        else:
            return None
    return current

# -----------------------------
# Call API / OData
# -----------------------------
all_rows = []
next_url = Data_Source

while next_url:
    response = requests.request(
        method=method,
        url=next_url,
        headers=headers,
        timeout=timeout_seconds
    )
    response.raise_for_status()

    response_json = response.json()
    rows = get_path_value(response_json, data_path)

    if rows is None:
        rows = []

    if isinstance(rows, list):
        all_rows.extend(rows)
    else:
        all_rows.append(rows)

    if pagination_type == "odataNextLink":
        next_url = get_path_value(response_json, next_link_path)
    else:
        next_url = None

# -----------------------------
# Write to Bronze Lakehouse table
# -----------------------------
if all_rows:
    bronze_df = spark.createDataFrame(all_rows)
    bronze_df = (
        bronze_df
        .withColumn("Ingestion_Timestamp", current_timestamp())
        .withColumn("Pipeline_Run_Id", lit(Pipeline_Run_Id))
        .withColumn("Spec_Code", lit(Spec_Code))
        .withColumn("Dataset_Code", lit(Dataset_Code))
    )
else:
    bronze_df = spark.createDataFrame(
        [],
        "Pipeline_Run_Id string, Spec_Code string, Dataset_Code string"
    )

bronze_df.write.format("delta").mode(write_mode).saveAsTable(Target_Name)

print(
    f"API ingestion completed. "
    f"Spec_Code={Spec_Code}, "
    f"Dataset_Code={Dataset_Code}, "
    f"Target_Name={Target_Name}, "
    f"Rows={len(all_rows)}"
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

