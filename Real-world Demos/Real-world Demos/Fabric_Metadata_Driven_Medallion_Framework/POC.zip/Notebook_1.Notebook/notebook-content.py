# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "8e3a0528-c97f-4ffe-a9eb-122c0986f836",
# META       "default_lakehouse_name": "RetailLakehouse",
# META       "default_lakehouse_workspace_id": "af8d3bd6-7c44-4d7f-961b-1e9fc550ac86",
# META       "known_lakehouses": [
# META         {
# META           "id": "8e3a0528-c97f-4ffe-a9eb-122c0986f836"
# META         }
# META       ]
# META     },
# META     "warehouse": {
# META       "default_warehouse": "9bdd0537-def6-4b2b-bc81-519b6bec357a",
# META       "known_warehouses": [
# META         {
# META           "id": "9bdd0537-def6-4b2b-bc81-519b6bec357a",
# META           "type": "Lakewarehouse"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

# ============================================
# NB_SILVER_DYNAMIC_TRANSFORM_ENTERPRISE
# Metadata-driven Silver transformation notebook
#
# Required parameters:
#   Spec_Code
#   Dataset_Code
#   Transform_Layer = Silver
#
# Reads:
#   ControlDB.config.TransformConfig
#
# Supports:
#   FullLoad / Overwrite
#   Append
#   Merge / DeltaLoad / IncrementalLoad
#   MergeWithDelete
# ============================================

import com.microsoft.sqlserver.jdbc.spark
from delta.tables import DeltaTable
from pyspark.sql.functions import col, current_timestamp, lit

# -----------------------------
# Parameters
# -----------------------------
Spec_Code = globals().get("Spec_Code", "BO5")
Dataset_Code = globals().get("Dataset_Code", "API_PRODUCTS")
Transform_Layer = globals().get("Transform_Layer", "Silver")

if not Spec_Code:
    raise ValueError("Spec_Code is required")

if not Dataset_Code:
    raise ValueError("Dataset_Code is required")

if not Transform_Layer:
    Transform_Layer = "Silver"

# -----------------------------
# ControlDB connection
# -----------------------------
control_db_server = "r6jir4thcxbujmagvc37ynczku-2y5y3l2epr7u3fq3d2p4kufmqy.msit-database.fabric.microsoft.com"
control_db_name = "ControlDB-32cb020c-4245-4f3e-94c5-40c1204b8058"

url = (
    f"jdbc:sqlserver://{control_db_server}:1433;"
    f"database={control_db_name};"
    f"encrypt=true;"
    f"trustServerCertificate=false;"
)

# -----------------------------
# Read TransformConfig
# -----------------------------
config_df = (
    spark.read
    .option("url", url)
    .mssql("config.TransformConfig")
)

config_df = config_df.filter(
    (col("Spec_Code") == Spec_Code) &
    (col("Transform_Layer") == Transform_Layer) &
    (col("Transform_Code") == Dataset_Code) &
    (col("Is_Active") == 1)
)

config_rows = config_df.collect()

if len(config_rows) == 0:
    raise ValueError(
        f"No active transform config found for "
        f"Spec_Code={Spec_Code}, Transform_Layer={Transform_Layer}, Transform_Code={Dataset_Code}"
    )

if len(config_rows) > 1:
    raise ValueError(
        f"Multiple active transform config rows found for "
        f"Spec_Code={Spec_Code}, Transform_Layer={Transform_Layer}, Transform_Code={Dataset_Code}"
    )

config = config_rows[0].asDict()

Transform_Code = config.get("Transform_Code")
Target_Table = config.get("Target_Table")
Transform_SQL = config.get("Transform_SQL")

# Optional config columns. Defaults keep current config working.
Load_Pattern = config.get("Load_Pattern") or config.get("Write_Mode") or "FullLoad"
Merge_Key_Columns = config.get("Merge_Key_Columns") or ""
Delete_Detection_Enabled = bool(config.get("Delete_Detection_Enabled") or False)
Delete_Column = config.get("Delete_Column") or ""
Delete_Value = str(config.get("Delete_Value") or "1")

if not Target_Table:
    raise ValueError("Target_Table is missing in TransformConfig")

if not Transform_SQL:
    raise ValueError("Transform_SQL is missing in TransformConfig")

print("============================================")
print("Silver transform started")
print(f"Spec_Code       : {Spec_Code}")
print(f"Dataset_Code    : {Dataset_Code}")
print(f"Transform_Code  : {Transform_Code}")
print(f"Target_Table    : {Target_Table}")
print(f"Load_Pattern    : {Load_Pattern}")
print(f"Merge_Key       : {Merge_Key_Columns}")
print("============================================")

# -----------------------------
# Execute transform SQL
# -----------------------------
source_df = spark.sql(Transform_SQL)

source_df = (
    source_df
    .withColumn("Silver_Updated_At", current_timestamp())
    .withColumn("Silver_Spec_Code", lit(Spec_Code))
    .withColumn("Silver_Dataset_Code", lit(Dataset_Code))
)

# -----------------------------
# Helper functions
# -----------------------------
def table_exists(table_name: str) -> bool:
    try:
        spark.table(table_name)
        return True
    except Exception:
        return False


def overwrite_table(df, target_table: str):
    df.write \
        .format("delta") \
        .mode("overwrite") \
        .option("overwriteSchema", "true") \
        .saveAsTable(target_table)


def append_table(df, target_table: str):
    df.write \
        .format("delta") \
        .mode("append") \
        .option("mergeSchema", "true") \
        .saveAsTable(target_table)


def merge_table(df, target_table: str, merge_keys: str):
    if not merge_keys:
        raise ValueError("Merge_Key_Columns is required for Merge/DeltaLoad")

    keys = [k.strip() for k in merge_keys.split(",") if k.strip()]

    if not keys:
        raise ValueError("Merge_Key_Columns is empty after parsing")

    if not table_exists(target_table):
        print(f"Target table {target_table} does not exist. Creating it first.")
        overwrite_table(df, target_table)
        return

    merge_condition = " AND ".join([f"target.{k} = source.{k}" for k in keys])

    delta_target = DeltaTable.forName(spark, target_table)

    if Delete_Detection_Enabled and Delete_Column:
        active_df = df.filter(~(col(Delete_Column).cast("string") == Delete_Value))
        delete_df = df.filter(col(Delete_Column).cast("string") == Delete_Value)

        if delete_df.count() > 0:
            delete_condition = " AND ".join([f"target.{k} = delete_source.{k}" for k in keys])
            delta_target.alias("target") \
                .merge(delete_df.alias("delete_source"), delete_condition) \
                .whenMatchedDelete() \
                .execute()

        if active_df.count() > 0:
            delta_target.alias("target") \
                .merge(active_df.alias("source"), merge_condition) \
                .whenMatchedUpdateAll() \
                .whenNotMatchedInsertAll() \
                .execute()
    else:
        delta_target.alias("target") \
            .merge(df.alias("source"), merge_condition) \
            .whenMatchedUpdateAll() \
            .whenNotMatchedInsertAll() \
            .execute()


# -----------------------------
# Write strategy
# -----------------------------
load_pattern = Load_Pattern.lower().replace(" ", "")

if load_pattern in ["fullload", "full", "overwrite"]:
    overwrite_table(source_df, Target_Table)

elif load_pattern in ["append", "appendload"]:
    append_table(source_df, Target_Table)

elif load_pattern in ["deltaload", "incrementalload", "merge", "mergewithdelete"]:
    merge_table(source_df, Target_Table, Merge_Key_Columns)

else:
    raise ValueError(f"Unsupported Load_Pattern / Write_Mode: {Load_Pattern}")

print("============================================")
print("Silver transform completed successfully")
print(f"Target table: {Target_Table}")
print(f"Rows processed: {source_df.count()}")
print("============================================")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
