# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "8e3a0528-c97f-4ffe-a9eb-122c0986f836",
# META       "default_lakehouse_name": "RetailLakehouse",
# META       "default_lakehouse_workspace_id": "af8d3bd6-7c44-4d7f-961b-1e9fc550ac86",
# META       "known_lakehouses": [
# META         {
# META           "id": "8e3a0528-c97f-4ffe-a9eb-122c0986f836"
# META         }
# META       ]
# META     },
# META     "warehouse": {
# META       "default_warehouse": "e6e9d431-349d-4e08-89b5-3270e99295f7",
# META       "known_warehouses": [
# META         {
# META           "id": "e6e9d431-349d-4e08-89b5-3270e99295f7",
# META           "type": "MountedWarehouse"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

# ============================================
# NB_DYNAMIC_TRANSFORM
# Reads transform settings from ControlDB.config.TransformConfig
# using Fabric Spark SQL DB connector
#
# Required parameters:
#   Spec_Code
#   Dataset_Code
#   Transform_Layer
# ============================================

import com.microsoft.sqlserver.jdbc.spark
from pyspark.sql.functions import col

Spec_Code = globals().get("Spec_Code", "BO5")
Dataset_Code = globals().get("Dataset_Code", "API_Categories")
Transform_Layer = globals().get("Transform_Layer", "Silver")

control_db_server = "r6jir4thcxbujmagvc37ynczku-2y5y3l2epr7u3fq3d2p4kufmqy.msit-database.fabric.microsoft.com"
control_db_name = "ControlDB-32cb020c-4245-4f3e-94c5-40c1204b8058"

url = (
    f"jdbc:sqlserver://{control_db_server}:1433;"
    f"database={control_db_name};"
    f"encrypt=true;"
    f"trustServerCertificate=false;"
)

config_df = (
    spark.read
    .option("url", url)
    .mssql("config.TransformConfig")
)

# IMPORTANT:
# TransformConfig does not have Dataset_Code, so match using Transform_Code pattern.
# Example:
#   Transform_Layer = Silver
#   Dataset_Code = API_PRODUCTS
#   Transform_Code = SILVER_API_PRODUCTS

expected_transform_code = Dataset_Code

config_df = config_df.filter(
    (col("Spec_Code") == Spec_Code) &
    (col("Transform_Layer") == Transform_Layer) &
    (col("Transform_Code") == Dataset_Code) &
    (col("Is_Active") == 1)
)

rows = config_df.collect()

if len(rows) == 0:
    raise ValueError(
        f"No active transform config found for "
        f"Spec_Code={Spec_Code}, "
        f"Transform_Layer={Transform_Layer}, "
        f"Transform_Code={expected_transform_code}"
    )

if len(rows) > 1:
    raise ValueError(
        f"Multiple active transform configs found for "
        f"Spec_Code={Spec_Code}, "
        f"Transform_Layer={Transform_Layer}, "
        f"Transform_Code={expected_transform_code}"
    )

config_row = rows[0].asDict()

Transform_Code = config_row.get("Transform_Code")
Transform_SQL = config_row.get("Transform_SQL")
Target_Table = config_row.get("Target_Table")
Write_Mode = config_row.get("Write_Mode") or "overwrite"

if not Transform_SQL:
    raise ValueError("Transform_SQL is missing in config.TransformConfig.")

if not Target_Table:
    raise ValueError("Target_Table is missing in config.TransformConfig.")

print("============================================")
print("NB_DYNAMIC_TRANSFORM started")
print(f"Spec_Code       : {Spec_Code}")
print(f"Dataset_Code    : {Dataset_Code}")
print(f"Transform_Layer : {Transform_Layer}")
print(f"Transform_Code  : {Transform_Code}")
print(f"Target_Table    : {Target_Table}")
print(f"Write_Mode      : {Write_Mode}")
print("Transform_SQL:")
print(Transform_SQL)
print("============================================")

df = spark.sql(Transform_SQL)

df.write \
    .format("delta") \
    .mode(Write_Mode) \
    .option("overwriteSchema", "true") \
    .saveAsTable(Target_Table)

#print("============================================")
print("Transform completed successfully")
print(f"Target table: {Target_Table}")
#print("============================================")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#df = spark.sql("SELECT * FROM RetailLakehouse.dbo.silver_api_categories LIMIT 1000")
#display(df)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
